package com.example.companyRegister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
